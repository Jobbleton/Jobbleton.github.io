The CyBloodJAS should be the server file run in a Java-based server.
The MainPageInfo file should be in the same location as the server file.
The MainScreen should be run in a JNLP-running web client.