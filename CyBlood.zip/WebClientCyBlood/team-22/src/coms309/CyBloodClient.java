package coms309;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class CyBloodClient
{
	boolean validCon = false;
	Socket socket;
	
	
	public void con() throws SocketException
	{
		con("localhost", 4000);
	}
	
	public void con(String host, int port) throws SocketException
	{
		try
		{
			this.socket = new Socket(host, port);
			this.validCon = true;
		}
		catch (UnknownHostException e) {
			System.out.println("Failed to connect to server: unknown host");
			this.validCon = false;
		}
		catch (IOException e) {
			System.out.println("Failed to connect to server: interrupted socket");
			this.validCon = false;
		}
		this.socket.setSoTimeout(900);
	}
	
	public void submit(String message)
	{
		PrintWriter out;
		try {
			out = new PrintWriter(this.socket.getOutputStream());
			out.println(message);
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public BufferedReader retrieve() throws IOException
	{
		BufferedReader input = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
		
		return input;
	}
	
	public List<String> retrieveMulti() throws IOException
	{
		List<String> data = new ArrayList<String>();
		char[] lineBreak = new char[]{'\r','\n'};
		int cI;
		char c;
		String s = "";
		try
		{
			InputStreamReader iR = new InputStreamReader(this.socket.getInputStream());
			cI = iR.read();
			while (cI != -1 || (char) cI != '\u0000')
			{
				c = (char) cI;
				if  (c != lineBreak[0] && c != lineBreak[1]) s += String.valueOf(c);
				else
				{
					if (!s.equals("")) data.add(s);
					s = "";
				}
			
					cI = iR.read();
			}
		}catch(java.net.SocketTimeoutException e)
		{
		}
		
		return data;
		
	}
	
	
	
	public void close() throws IOException
	{
		this.socket.close();
	}

}