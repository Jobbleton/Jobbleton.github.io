package coms309;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.JTable;


public class TableListener implements ListSelectionListener {
	JTable table;
	int rowI, colI;
	
	public TableListener()
	{
		
	}
	
	public TableListener(JTable t)
	{
		this.table = t;
	}
	
	public void valueChanged(ListSelectionEvent ev) 
	{
		JOptionPane.showMessageDialog(null,"started");
		if (ev.getSource() ==  this.table.getSelectionModel() && this.table.getCellSelectionEnabled())
		{
			this.rowI = this.table.getSelectedRow();
		    this.colI = this.table.getSelectedColumn();
		}
		else
		{
			JOptionPane.showMessageDialog(null,"Event fired");
		}
	}
	
	public void showMessage()
	{
		JOptionPane.showMessageDialog(null,this.rowI + ":" + this.colI);
	}
}