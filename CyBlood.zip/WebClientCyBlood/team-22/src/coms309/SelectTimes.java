package coms309;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;

public class SelectTimes {

	public static void main(String[] args) {
		new SelectTimes();
	}

	public SelectTimes() {
		startUI();
	}

	MyTableModel model = new MyTableModel();

	public void startUI() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager
							.getSystemLookAndFeelClassName());
				} catch (ClassNotFoundException | InstantiationException
						| IllegalAccessException
						| UnsupportedLookAndFeelException ex) {
					ex.printStackTrace();
				}

				String[] columnNames = { "Times", "Monday", "Tuesday",
						"Wednesday", "Thursday" };
				String[] times = { "10:00", "10:20", "10:40", "11:00", "11:20",
						"11:40", "12:00", "12:20", "12:40", "1:00", "1:20",
						"1:40", "2:00", "2:20", "2:40", "3:00", "3:20", "3:40",
						"4:00" };

				for (int i = 0; i < times.length; i++) {
					model.addRow(new Object[] { times[i], false, false, false,
							false });
				}

				JTable table = new JTable(model);
				table.setBackground(Color.RED);
				table.setForeground(Color.YELLOW);
				table.setFont(new Font("Eras Demi ITC", Font.PLAIN, 12));

				JButton submitData = new JButton("Submit");
				submitData.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					}
				});
				submitData.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent arg0) {
						// NO VALIDATION NEEDED, ENTER CODE TO SET UP FRAME HERE
						String s = model.getData();
						System.out.println(s);
					}
				});
				submitData.setBounds(150, 350, 150, 25);
				submitData.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
				submitData.setForeground(Color.BLACK);

				JFrame frame = new JFrame("Select Times");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.add(submitData);
				frame.add(new JScrollPane(table));

				// frame.add(submitData);

				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}

	public class MyTableModel extends DefaultTableModel {

		public MyTableModel() {
			super(new String[] { "Time", "Monday", "Tuesday", "Wednesday",
					"Thursday" }, 0);
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			Class clazz = String.class;
			switch (columnIndex) {
			case 0:
				clazz = Integer.class;
				break;
			case 1:
				clazz = Boolean.class;
				break;
			case 2:
				clazz = Boolean.class;
				break;
			case 3:
				clazz = Boolean.class;
				break;
			case 4:
				clazz = Boolean.class;
				break;
			}
			return clazz;
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			return column >= 1;
		}

		@Override
		public void setValueAt(Object aValue, int row, int column) {
			if (aValue instanceof Boolean && column >= 1) {
				Vector rowData = (Vector) getDataVector().get(row);
				rowData.set(column, (boolean) aValue);
				fireTableCellUpdated(row, column);
			}
		}

		private String getData() {
			int m = model.getRowCount();
			int n = model.getColumnCount();
			String[][] data = new String[m][n];

			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					data[i][j] = (model.getValueAt(i, j).toString());
				}
			}
			String s = "";
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					if (data[i][j].equals("true")) {
						String day = "";
						if (j == 1)
							day = "Monday";
						if (j == 2)
							day = "Tuesday";
						if (j == 3)
							day = "Wednesday";
						if (j == 4)
							day = "Thursday";
						s += day + "," + data[i][0] + " ";
					}
				}
			}
			return s;
		}
	}
}
