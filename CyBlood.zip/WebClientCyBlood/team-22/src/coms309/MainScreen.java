package coms309;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.plaf.ColorUIResource;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainScreen {

	private static JFrame frame;
	// for debug, all in donor tab
	// will be moved later to proper location
	private static JTextField emailField;
	private static JTextField vEmailField;
	private static JTextField vPasswordField;
	private static JTextField aEmailField;
	private static JTextField aPasswordField;

	private static String inputEmail = "";
	private static String inputPassword = "";
	private static String inputTime = "";

	// entry level is either donor, volun, or admin for basic access checks
	private static String inputEntryLevel = "";
	private static JTextField emailFieldOldUser;
	private static JTextField passwordFieldOldUser;
	private static JTextField emailFieldNewUser;
	private static JTextField passwordFieldNewUSer;
	private static JTextArea errorDonorArea;

	private static JPanel donateNowPanel;
	private static JPanel volunteersPanel;
	private static JPanel administrationPanel;

	private static MyTableModel modelUsed;

	public static boolean validateLogin(String inputEmail, String accountLevel,
			String inputPassword) throws IOException {
		String answer;
		BufferedReader br;
		CyBloodClient c = new CyBloodClient();
		c.con();
		c.submit("validateLogin;AccountInfo;" + inputEmail + ";" + accountLevel
				+ ";" + inputPassword);
		System.out.println("?");
		br = c.retrieve();
		answer = br.readLine();
		System.out.println(answer);
		try {

			c.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (answer.equals("1"))
			return true;
		return false;
	}
	
	
	public static String displayTime(String inputEmail, String account) throws IOException
	{
		List<String> timeData = new ArrayList<String>();
		List<String> allData;
		BufferedReader br;
		CyBloodClient c = new CyBloodClient();
		String[] data;
		String line, times;
		times = "";
		c.con();
		c.submit("retrieveData;"+ account +"; ; ; ");
		allData = c.retrieveMulti();
		
		for (String s: allData)
		{
			data = s.split(";");
			if (data[0].equals(inputEmail)) 
			{
				timeData.add(data[1]);
			}
			System.out.println(s);
		}
		
		System.out.println(timeData.size());
		for (String s: timeData)
		{
			times += s + "\n";
			System.out.println(s);
		}
		try {

			c.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return times;
	}
	
	public static void main(String[] args) {
		// creating window
		frame = new JFrame("CyBlood: Demo the Fourth");
		// backing color is yellow (gold)
		frame.getContentPane().setBackground(Color.RED);
		// program ends when window is closed
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		UIManager.put("TabbedPane.contentAreaColor ", ColorUIResource.RED);
		UIManager.put("TabbedPane.selected", ColorUIResource.RED);
		UIManager.put("TabbedPane.background", ColorUIResource.RED);
		UIManager.put("TabbedPane.shadow", ColorUIResource.RED);
		UIManager.put("TabbedPane.darkShadow", ColorUIResource.RED);
		UIManager.put("TabbedPane.focus", ColorUIResource.RED);
		UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0));
		JPanel administrationPanel = new JPanel((LayoutManager) null);
		// main pane underneath app header
		JTabbedPane pane = new JTabbedPane();
		pane.setBounds(0, 38, 994, 654);
		pane.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null,
				null));
		pane.setBackground(Color.YELLOW);
		pane.setForeground(Color.BLACK);
		pane.setFont(new Font("Eras Demi ITC", Font.BOLD, 12));
		// no layout, free range of pane placement
		frame.getContentPane().setLayout(null);

		// primary (first) pane
		JPanel mainPane = new JPanel(null);
		mainPane.setBorder(new BevelBorder(BevelBorder.RAISED, null, null,
				null, null));
		mainPane.setBackground(Color.RED);
		pane.addTab("Main Page", mainPane);

		// reads MainPageInfo.txt on client, will be moved to server side later
		File mainPageIn = new File("src/MainPageInfo.txt");
		Scanner mainPageScan;
		String mainInfo = "";
		try {
			mainPageScan = new Scanner(mainPageIn);
			while (mainPageScan.hasNext()) {
				mainInfo += mainPageScan.nextLine() + "\n";
			}
			mainPageScan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// above will be moved to server

		// general information tab
		// only contains label for general info and information read off the
		// MainPageInfo.txt
		JLabel lblNewLabel = new JLabel("General Information");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Eras Bold ITC", Font.PLAIN, 16));
		lblNewLabel.setBounds(10, 11, 213, 168);
		mainPane.add(lblNewLabel);

		JTextArea MainPageText = new JTextArea();
		MainPageText.setText(mainInfo);
		MainPageText.setBounds(50, 50, 800, 500);
		MainPageText.setFont(new Font("Eras Demi ITC", Font.PLAIN, 14));
		MainPageText.setBackground(Color.RED);
		MainPageText.setForeground(Color.BLACK);
		mainPane.add(MainPageText);
		// end of general information tab

		// donate now tab
		donateNowPanel = new JPanel((LayoutManager) null);
		donateNowPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null,
				null, null, null));
		donateNowPanel.setBackground(Color.RED);
		pane.addTab("Donate Now", null, donateNowPanel, null);

		JLabel lblthisIsWhere = new JLabel("This is the Log-In page for Donors");
		lblthisIsWhere.setVerticalAlignment(SwingConstants.TOP);
		lblthisIsWhere.setForeground(Color.BLACK);
		lblthisIsWhere.setBackground(Color.WHITE);
		lblthisIsWhere.setFont(new Font("Eras Bold ITC", Font.PLAIN, 16));
		lblthisIsWhere.setBounds(10, 11, 280, 25);
		donateNowPanel.add(lblthisIsWhere);

		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(135, 186, 161, 25);
		donateNowPanel.add(emailField);

		JButton btnNoAccountLogin = new JButton("Continue onto Time Select");
		btnNoAccountLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNoAccountLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				// NO VALIDATION NEEDED, ENTER CODE TO SET UP FRAME HERE
				openTimeTable("Donor");
			}
		});
		btnNoAccountLogin.setBounds(117, 221, 206, 25);
		btnNoAccountLogin.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		btnNoAccountLogin.setForeground(Color.BLACK);
		donateNowPanel.add(btnNoAccountLogin);

		JLabel lblEmail = new JLabel("E-Mail Address:");
		lblEmail.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		lblEmail.setForeground(Color.BLACK);
		lblEmail.setBounds(36, 186, 95, 14);
		donateNowPanel.add(lblEmail);

		JTextArea textFieldJustEmail = new JTextArea();
		textFieldJustEmail.setFont(new Font("Eras Demi ITC", Font.ITALIC, 13));
		textFieldJustEmail
				.setText("Please fill out the form below\r\nto proceed without making an account.");
		textFieldJustEmail.setBackground(Color.RED);
		textFieldJustEmail.setForeground(Color.BLACK);
		textFieldJustEmail.setBounds(90, 127, 255, 36);
		donateNowPanel.add(textFieldJustEmail);

		JTextArea testFieldMakeAnAccount = new JTextArea();
		testFieldMakeAnAccount
				.setText("If you would like to make an account to\r\nchange your time in the future,\r\nfill out the form below.");
		testFieldMakeAnAccount.setFont(new Font("Eras Demi ITC", Font.ITALIC,
				13));
		testFieldMakeAnAccount.setBackground(Color.RED);
		testFieldMakeAnAccount.setForeground(Color.BLACK);
		testFieldMakeAnAccount.setBounds(650, 111, 255, 50);
		donateNowPanel.add(testFieldMakeAnAccount);

		JTextArea textFieldOldUsers = new JTextArea();
		textFieldOldUsers
				.setText("If you already have an account,\r\nfill out the form below to log back in\r\nand change your Times.");
		textFieldOldUsers.setFont(new Font("Eras Demi ITC", Font.ITALIC, 13));
		textFieldOldUsers.setBackground(Color.RED);
		textFieldOldUsers.setForeground(Color.BLACK);
		textFieldOldUsers.setBounds(371, 111, 255, 52);
		donateNowPanel.add(textFieldOldUsers);

		emailFieldOldUser = new JTextField();
		emailFieldOldUser.setColumns(10);
		emailFieldOldUser.setBounds(392, 186, 161, 25);
		donateNowPanel.add(emailFieldOldUser);

		passwordFieldOldUser = new JTextField();
		passwordFieldOldUser.setColumns(10);
		passwordFieldOldUser.setBounds(392, 221, 161, 25);
		donateNowPanel.add(passwordFieldOldUser);

		emailFieldNewUser = new JTextField();
		emailFieldNewUser.setColumns(10);
		emailFieldNewUser.setBounds(693, 186, 161, 25);
		donateNowPanel.add(emailFieldNewUser);

		passwordFieldNewUSer = new JTextField();
		passwordFieldNewUSer.setColumns(10);
		passwordFieldNewUSer.setBounds(693, 221, 161, 25);
		donateNowPanel.add(passwordFieldNewUSer);

		JButton btnValidateDonorLogin = new JButton(
				"Validate Login and Continue");
		btnValidateDonorLogin.setForeground(Color.BLACK);
		btnValidateDonorLogin
				.setFont(new Font("Eras Bold ITC", Font.ITALIC, 12));
		btnValidateDonorLogin.setBounds(371, 256, 206, 25);
		donateNowPanel.add(btnValidateDonorLogin);
		btnValidateDonorLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnValidateDonorLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				inputEmail = emailFieldOldUser.getText().trim();
				inputPassword = passwordFieldOldUser.getText().trim();
				inputEntryLevel = "Don";
				String message, times;
				boolean login;
				try {
					login = validateLogin(inputEmail, inputEntryLevel,
							inputPassword);
					if (login)
					{
						times = displayTime(inputEmail, "DonorInfo");
						JOptionPane.showMessageDialog(null, "You have signed up for these times:\n" +times, null,
								JOptionPane.PLAIN_MESSAGE);
						openTimeTable("Donor");
					}
					else
					{
						message = "That email/password combination does not exist.";
						JOptionPane.showMessageDialog(null, message, null,
							JOptionPane.PLAIN_MESSAGE);
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		JButton btnCreateAccountLogin = new JButton(
				"Create Account and Continue");
		btnCreateAccountLogin.setForeground(Color.BLACK);
		btnCreateAccountLogin
				.setFont(new Font("Eras Bold ITC", Font.ITALIC, 12));
		btnCreateAccountLogin.setBounds(670, 256, 216, 25);
		donateNowPanel.add(btnCreateAccountLogin);

		btnCreateAccountLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCreateAccountLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				inputEmail = emailFieldNewUser.getText().trim();
				inputPassword = passwordFieldNewUSer.getText().trim();
				inputEntryLevel = "Don";
				CyBloodClient c = new CyBloodClient();
				try {
					c.con();
				} catch (SocketException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				c.submit("insertData;AccountInfo;'" + inputEmail
						+ "','" + inputEntryLevel+ "','" + inputPassword + "','"
						+ inputEmail + "',1234567890; ;");

				// CATCH BACK SERVER INFO

				try {
					c.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		errorDonorArea = new JTextArea();
		errorDonorArea.setBounds(365, 326, 222, 75);
		donateNowPanel.add(errorDonorArea);

		// Volunteers tab

		volunteersPanel = new JPanel((LayoutManager) null);
		volunteersPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null,
				null, null, null));
		volunteersPanel.setBackground(Color.RED);
		pane.addTab("Volunteers", null, volunteersPanel, null);

		vEmailField = new JTextField();
		vPasswordField = new JTextField();

		vEmailField.setColumns(10);
		vEmailField.setBounds(355, 186, 161, 25);
		volunteersPanel.add(vEmailField);
		vPasswordField.setColumns(10);
		vPasswordField.setBounds(355, 221, 161, 25);
		volunteersPanel.add(vPasswordField);

		JLabel vLblEmail = new JLabel("E-Mail Address:");
		vLblEmail.setBounds(232, 191, 95, 14);
		vLblEmail.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		vLblEmail.setForeground(Color.BLACK);
		volunteersPanel.add(vLblEmail);

		JLabel vLblPassword = new JLabel("Password:");
		vLblPassword.setBounds(242, 226, 95, 14);
		vLblPassword.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		vLblPassword.setForeground(Color.BLACK);
		volunteersPanel.add(vLblPassword);

		JButton vSubmitButton = new JButton("Submit");
		vSubmitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				inputEmail = vEmailField.getText().trim();
				inputPassword = vPasswordField.getText().trim();
				inputEntryLevel = "Vol";
				String message, times;
				boolean login;
				try {
					login = validateLogin(inputEmail, inputEntryLevel,
							inputPassword);
					if (login)
					{
						times = displayTime(inputEmail, "VolunteerInfo");
						JOptionPane.showMessageDialog(null, "You have signed up for these times:\n" +times, null,
								JOptionPane.PLAIN_MESSAGE);
						openTimeTable("Volunteer");
					}
					
					else
					{
						message = "That email/password combination does not exist.";
						JOptionPane.showMessageDialog(null, message, null,
							JOptionPane.PLAIN_MESSAGE);
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		
		
		vSubmitButton.setBounds(393, 256, 89, 23);
		vSubmitButton.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		volunteersPanel.add(vSubmitButton);

		JLabel lblVolunFiller = new JLabel(
				"This is the Log-In page for Volunteers");
		lblVolunFiller.setVerticalAlignment(SwingConstants.TOP);
		lblVolunFiller.setForeground(Color.BLACK);
		lblVolunFiller.setBackground(Color.WHITE);
		lblVolunFiller.setFont(new Font("Eras Bold ITC", Font.PLAIN, 16));
		lblVolunFiller.setBounds(10, 11, 486, 168);
		volunteersPanel.add(lblVolunFiller);

		// Administration tab

		administrationPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null,
				null, null, null));
		administrationPanel.setBackground(Color.RED);
		pane.addTab("Administration", null, administrationPanel, null);

		aEmailField = new JTextField();
		aPasswordField = new JTextField();

		aEmailField.setColumns(10);
		aEmailField.setBounds(355, 186, 161, 25);
		administrationPanel.add(aEmailField);
		aPasswordField.setColumns(10);
		aPasswordField.setBounds(355, 221, 161, 25);
		administrationPanel.add(aPasswordField);

		JLabel aLblEmail = new JLabel("E-Mail Address:");
		aLblEmail.setBounds(232, 191, 95, 14);
		aLblEmail.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		aLblEmail.setForeground(Color.BLACK);
		administrationPanel.add(aLblEmail);

		JLabel aLblPassword = new JLabel("Password:");
		aLblPassword.setBounds(242, 226, 95, 14);
		aLblPassword.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		aLblPassword.setForeground(Color.BLACK);
		administrationPanel.add(aLblPassword);

		JButton aSubmitButton = new JButton("Submit");
		aSubmitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				inputEmail = aEmailField.getText().trim();
				inputPassword = aPasswordField.getText().trim();
				inputEntryLevel = "Adm";
				String message, times;
				boolean login;
				try {
					login = validateLogin(inputEmail, inputEntryLevel,
							inputPassword);
					if (login){
						message = "You have been logged in.";
						times = displayTime(inputEmail, "ClinicInfo");
						JOptionPane.showMessageDialog(null, "You have signed up for these times:\n" +times, null,
								JOptionPane.PLAIN_MESSAGE);
						openTimeTable("Admin");
					}
						
					else
						message = "That email/password combination does not exist.";
					JOptionPane.showMessageDialog(null, message, null,
							JOptionPane.PLAIN_MESSAGE);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		aSubmitButton.setBounds(393, 256, 89, 23);
		aSubmitButton.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		administrationPanel.add(aSubmitButton);

		JLabel lblAdminFiller = new JLabel(
				"This is the Log-In page for Administrators");
		lblAdminFiller.setVerticalAlignment(SwingConstants.TOP);
		lblAdminFiller.setForeground(Color.BLACK);
		lblAdminFiller.setBackground(Color.WHITE);
		lblAdminFiller.setFont(new Font("Eras Bold ITC", Font.PLAIN, 16));
		lblAdminFiller.setBounds(10, 11, 486, 168);
		administrationPanel.add(lblAdminFiller);

		frame.getContentPane().add(pane);

		JLabel lblPageHeader = new JLabel(
				"CyBlood Application for Iowa State University");
		lblPageHeader.setForeground(Color.YELLOW);
		lblPageHeader.setFont(new Font("Eras Bold ITC", Font.BOLD, 24));
		lblPageHeader.setBounds(0, 0, 994, 39);
		frame.getContentPane().add(lblPageHeader);

		frame.setSize(1000, 720);
		frame.setResizable(false);
		frame.setVisible(true);
	}

	// creates the command line that will be written and given to the server
	private static String commandToSocket(String command) {
		return (command + "," + inputEmail + "," + inputPassword + ","
				+ inputTime + "," + inputEntryLevel);
	}

	private static void openTimeTable(String panel) {
		String[] times = { "10:00", "10:20", "10:40", "11:00", "11:20",
				"11:40", "12:00", "12:20", "12:40", "1:00", "1:20", "1:40",
				"2:00", "2:20", "2:40", "3:00", "3:20", "3:40", "4:00" };

		modelUsed = new MyTableModel();

		JPanel p;
		p = administrationPanel;
		modelUsed.donor = false;
		modelUsed.AccountType = "Admin";
		
		
		if (panel == "Donor")
		{
			p = donateNowPanel;
			modelUsed.donor = true;
			modelUsed.AccountType = "Donor";
		}
		else if (panel == "Volunteer")
		{
			p = volunteersPanel;
			modelUsed.donor = false;
			modelUsed.AccountType = "Volunteer";
		}
		for (int i = 0; i < times.length; i++) {
			modelUsed.addRow(new Object[] { times[i], false, false, false,
					false });
		}

		JTable table = new JTable(modelUsed);
		table.setBackground(Color.RED);
		table.setForeground(Color.YELLOW);
		table.setFont(new Font("Eras Demi ITC", Font.PLAIN, 12));

		JButton submitData = new JButton("Submit");
		submitData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		submitData.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				// NO VALIDATION NEEDED, ENTER CODE TO SET UP FRAME HERE
				try {
					modelUsed.submitTimeData();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		submitData.setBounds(420, 400, 150, 25);
		submitData.setFont(new Font("Eras Bold ITC", Font.PLAIN, 12));
		submitData.setForeground(Color.BLACK);

		p.removeAll();
		JScrollPane tempScrPane = new JScrollPane(table);
		tempScrPane.setBounds(200, 38, 594, 350);
		p.add(tempScrPane, BorderLayout.CENTER);
		p.add(submitData);
		p.revalidate();
		p.repaint();
	}

	public static class MyTableModel extends DefaultTableModel {
		private static final long serialVersionUID = 1L;
		public boolean donor;
		public String AccountType;

		public MyTableModel() {
			super(new String[] { "Time", "Monday", "Tuesday", "Wednesday",
					"Thursday" }, 0);
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			Class<?> clazz = String.class;
			switch (columnIndex) {
			case 0:
				clazz = Integer.class;
				break;
			case 1:
				clazz = Boolean.class;
				break;
			case 2:
				clazz = Boolean.class;
				break;
			case 3:
				clazz = Boolean.class;
				break;
			case 4:
				clazz = Boolean.class;
				break;
			}
			return clazz;
		}

		private String getSubmitCommand(String data, String accountType) throws IOException
		{
			//1,1:40
			String uID, table, clinicName;
			if (accountType == "Donor")
			{
				uID = emailField.getText().trim();
				if (uID.equals("") || uID.length() <= 2) uID = emailFieldOldUser.getText().trim();
				table = "DonorInfo";
				clinicName = "";
			}
			else if (accountType == "Admin")
			{
				uID = aEmailField.getText().trim();
				table = "ClinicInfo";
				clinicName = "','Red Cross";
			}
			else
			{
				uID = vEmailField.getText().trim();
				table = "VolunteerInfo";
				clinicName = "','Red Cross";
			}
			String[] st;
			String sql = "insertData;" + table + ";'" + uID + "','";
			String day;
			st = data.split(",");
			day = Integer.toString(23 + Integer.parseInt(st[0]));
			
			sql += "2015-03-" + day + " " + st[1].trim() + ":00.0" + clinicName +"';' ';' ';' '";
			CyBloodClient c = new CyBloodClient();;
			c.con();
			c.submit("deleteData;" + table + ";" + uID +"; ; ; ");
			c.close();
			
			try {
			    Thread.sleep(500);                 //1000 milliseconds is one second.
			} catch(InterruptedException ex) {
			    Thread.currentThread().interrupt();
			}
			
			return sql;
		}
		
		private void submitTimeData() throws IOException
		{
			ArrayList<String> tL = getData();
			String test;
			if (tL.size() >= 2 && this.donor) JOptionPane.showMessageDialog(null, "You can only donate once.");
			else
			{
				CyBloodClient c = new CyBloodClient();
				
				for (String s: tL)
				{	
					test = getSubmitCommand(s,this.AccountType);
					c.con();
					c.submit(test);
					c.close();
				}
			}
		}
		private ArrayList<String> getData() {
			int m = modelUsed.getRowCount();
			int n = modelUsed.getColumnCount();
			String[][] data = new String[m][n];
			List<String> timesSelected = new ArrayList<String>();

			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					data[i][j] = (modelUsed.getValueAt(i, j).toString());
				}
			}
			
			String s = "";
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					if (data[i][j].equals("true")) {
						s = "";
						s += j + "," + data[i][0] + " ";
						timesSelected.add(s);
					}
				}
			}
			return (ArrayList<String>) timesSelected;
		}

		@Override
		public boolean isCellEditable(int row, int column) {
			return column >= 1;
		}

		@Override
		public void setValueAt(Object aValue, int row, int column) {
			if (aValue instanceof Boolean && column >= 1) {
				Vector rowData = (Vector) getDataVector().get(row);
				rowData.set(column, (boolean) aValue);
				fireTableCellUpdated(row, column);
			}
		}
	}
}
