import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class CyBloodJAS
{

	public static void main(String[] args) throws IOException
	{

		ServerSocket serverSocket = null;
		int clientNum = 0; // keeps track of how many clients were created

		// 1. CREATE A NEW SERVERSOCKET
		try
		{
			serverSocket = new ServerSocket(4000); // provide MYSERVICE at port
													// 4000
			// System.out.println(serverSocket);
		} catch (IOException e)
		{
			System.out.println("Could not listen on port: 4001");
			System.out.println(e.getMessage());
			System.exit(-1);
		}

		// 2. LOOP FOREVER - SERVER IS ALWAYS WAITING TO PROVIDE SERVICE!
		while (true)
		{
			Socket clientSocket = null;
			try
			{
				// 2.1 WAIT FOR CLIENT TO TRY TO CONNECT TO SERVER
				System.out.println("Waiting for client " + (clientNum + 1) + " to connect!");
				System.out.println("Port Number is: " + serverSocket.getLocalPort());
				clientSocket = serverSocket.accept();

				// 2.2 SPAWN A THREAD TO HANDLE CLIENT REQUEST
				System.out.println("Server got connected to client" + ++clientNum);
				Thread t = new Thread(new CyBloodJASClientHandler(clientSocket, clientNum));
				t.start();

			}
			catch (IOException e)
			{
				System.out.println("Accept failed on port 4000");
				System.exit(-1);
			}

			// 2.3 GO BACK TO WAITING FOR OTHER CLIENTS
			// (While the thread that was created handles the connected client's
			// request)

		} // end while loop
	} // end of main method

} // end of class MyServer

class CyBloodJASClientHandler implements Runnable
{
	Socket s; // this is socket on the server side that connects to the CLIENT
	int num; // keeps track of its number just for identifying purposes

	CyBloodJASClientHandler(Socket s, int n)
	{
		this.s = s;
		num = n;
	}

	// This is the client handling code
	public void run()
	{
		// printSocketInfo(s); // just print some information at the server side
		// about the connection
		Scanner in;

		try
		{
			// 1. USE THE SOCKET TO READ WHAT THE CLIENT IS SENDING
			in = new Scanner(s.getInputStream());
			while (in.hasNextLine())
			{
				// clientMessage should be in the format:
				// command,email,password,time,level
				String clientMessage = in.nextLine();
				String[] lines = clientMessage.split(";");
				if (lines.length >= 4)
				{
					if (lines[0].equals("error"))
					{
						//validateLogin(lines);
					}
					else if (lines[0].equals("addEmailandTime"))
					{
						addEmailandTime(lines[1], lines[3]);
					}
					else if (lines[0].equals("validateLogin"))
					{
						retrieveData("Select COUNT(*) From " + lines[1] + 
								" Where email = '" + lines[2] + "' &&  "
										+ "AccountType = '" + lines[3] + "' "
												+ "&& password = '" + lines[4] + "';");
					}
					else if (lines[0].equals("submit"))
					{
						addAccount(lines[1], lines[2], lines[3]);
					}
					else if (lines[0].equals("retrieveEntryLevel"))
					{
						retrieveEntryLevel(lines[1]);
					}
					else if (lines[0].equals("insertData"))
					{
						insertData("INSERT INTO db30922." + lines[1] + " VALUES (" + lines[2] + ");");
					}
					
					else if (lines[0].equals("retrieveData"))
					{
						retrieveData("SELECT * FROM db30922." + lines[1] + ";");
					}
					else
					{
						// DEBUG
						System.out.println("Invalid command");
					}
				}
				else
				{
					System.out.println("message received is in improper format");
				}
				// DEBUG
				System.out.println(clientMessage);				
			}

		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		// This handling code dies after doing all the printing
	} // end of method run()

	void printMainPageInfo()
	{
		// reads MainPageInfo.txt on client, will be moved to server side later
		File mainPageIn = new File("src/MainPageInfo.txt");
		Scanner mainPageScan;
		String mainInfo = "";
		try
		{
			mainPageScan = new Scanner(mainPageIn);
			while (mainPageScan.hasNext())
			{
				mainInfo += mainPageScan.nextLine() + "\n";
			}
			mainPageScan.close();
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(mainInfo);
	}

	void printSocketInfo(Socket s)
	{
		System.out.println("Socket on Server " + Thread.currentThread() + " ");
		System.out.println("Server socket Local Address: " + s.getLocalAddress() + ":" + s.getLocalPort());
		System.out.println("Server socket Remote Address: "+ s.getRemoteSocketAddress());
	} // end of printSocketInfo

	private void insertData(String command) throws IOException
	{
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 

		Connection conn = null;
		PreparedStatement statementToExecute = null;
		ResultSet queryResult = null;

		String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
		String dbUser = "u30922";
		String dbPass = "FPHZ44MveU";

		//attempt to update password table
		try
		{
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
			statementToExecute = conn.prepareStatement(command);
			int affectedRows = statementToExecute.executeUpdate();
			
			if (affectedRows == 0) sendToSocket("False");
			else sendToSocket("True");
			

			//DEBUG
			System.out.println("Executed query, retrieving data.");

		}
		catch (SQLException e)
		{
			System.out.println("Exception occurred trying to connect to database or while querying.");
			System.out.println(command);
			e.printStackTrace();

		}

		//closing open connections
		try
		{
			if (queryResult != null)
			{
				queryResult.close();
			}
			if (statementToExecute != null)
			{
				statementToExecute.close();
			}
			if (conn != null)
			{
				conn.close();
			}
		}
		catch (SQLException e)
		{
			System.out.println("Exception occurred trying to close sql connections.");
			e.printStackTrace();
		}

	}

	private void addEmailandTime(String email, String time)
	{
		// DEBUG
		System.out.println("This will add a the new email: " + email + " and time: " + time + " to the database");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 

		Connection conn = null;
		PreparedStatement statementToExecute = null;
		ResultSet queryResult = null;

		String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
		String dbUser = "u30922";
		String dbPass = "FPHZ44MveU";

		//attempt to update time table
		try
		{
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
			statementToExecute = conn.prepareStatement("INSERT INTO 'db30922'.'emailTime' ('email','Time' VALUES ('"+ email +"', '"+ time +"')");
			queryResult = statementToExecute.executeQuery();

			//DEBUG
			System.out.println("Executed query, retrieving data.");

			while (queryResult.next())
			{
				System.out.print(queryResult.getString(1) + " ");
				System.out.println(queryResult.getString(2));
			}

		}
		catch (SQLException e)
		{
			System.out.println("Exception occurred trying to connect to database or while querying.");
			e.printStackTrace();

		}

		//closing open connections
		try
		{
			if (queryResult != null)
			{
				queryResult.close();
			}
			if (statementToExecute != null)
			{
				statementToExecute.close();
			}
			if (conn != null)
			{
				conn.close();
			}
		}
		catch (SQLException e)
		{
			System.out.println("Exception occurred trying to close sql connections.");
			e.printStackTrace();
		}
	}


	private void addAccount(String email, String password, String time)
	{
		// DEBUG
		//System.out.println("This will add a the new email: " + email + " password: " + password + " and time: " + time + " to the database");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement statementToExecute = null;
        ResultSet queryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("INSERT INTO 'db30922'.'emailPass' ('email','password' VALUES ('"+ email +"', '"+ password +"')");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while (queryResult.next())
            {
            	System.out.print(queryResult.getString(1) + " ");
            	System.out.println(queryResult.getString(2));
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();

        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
        
        //attempt to update time table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("INSERT INTO 'db30922'.'emailTime' ('email','Time' VALUES ('"+ email +"', '"+ time +"')");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while (queryResult.next())
            {
            	System.out.print(queryResult.getString(1) + " ");
            	System.out.println(queryResult.getString(2));
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();

        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	private void retrieveEntryLevel(String email)
	{
		//DEBUG
		System.out.println("This is searching for the level attached to the email: " + email);
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement statementToExecute = null;
        ResultSet queryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("SELECT * FROM db30922.emailLevel where email=" + email + ";");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            if(queryResult.next())
            {
            	//DEBUG
            	System.out.println(queryResult.getString(2));
            }
            else
            {
            	//none found
            	System.out.println("No email found");
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();
        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	private void retrieveAllEmails()
	{
		//DEBUG
		System.out.println("This is retrieving all emails with passwords");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement statementToExecute = null;
        ResultSet queryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("SELECT * FROM db30922.emailPassword;");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while(queryResult.next())
            {
            	//DEBUG
            	System.out.println(queryResult.getString(1));
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();
        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	private void retrieveAllEmailsAndPasswords()
	{
		//DEBUG
		System.out.println("This is retrieving all emails with passwords");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement statementToExecute = null;
        ResultSet queryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("SELECT * FROM db30922.emailPassword;");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while(queryResult.next())
            {
            	//DEBUG
            	System.out.println(queryResult.getString(1));
            	System.out.println(queryResult.getString(2));
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();
        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	private void retrieveAllEmailsAndTimes()
	{
		//DEBUG
		System.out.println("This is retrieving all emails with passwords");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement statementToExecute = null;
        ResultSet queryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            statementToExecute = conn.prepareStatement("SELECT * FROM db30922.emailTime;");
            queryResult = statementToExecute.executeQuery();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while(queryResult.next())
            {
            	//DEBUG
            	System.out.println(queryResult.getString(1));
            	System.out.println(queryResult.getString(2));
            }

        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();
        }
        
        //closing open connections
        try
        {
        	if (queryResult != null)
        	{
        		queryResult.close();
        	}
        	if (statementToExecute != null)
        	{
        		statementToExecute.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	private String getColumns(ResultSet queryResult, ResultSetMetaData rsmd) throws SQLException
	{
		String data = "";
		int colNum = rsmd.getColumnCount();
		for (int i = 1; i <= colNum; i++)
		{
			data += queryResult.getString(i) + ";";
		}
		
		data = data.substring(0, data.length()-1);
		return data;
	}
	
	private void retrieveData(String command) throws IOException
	{
		//DEBUG
		System.out.println("This is retrieving all account info");
		
		//try catch for drivers
		try
		{ 
			// Load the driver (registers itself)
			Class.forName("com.mysql.jdbc.Driver"); 
		} 
		catch (Exception E)
		{ 
			System.err.println ("Unable to load driver.");  
			E.printStackTrace (); 
		} 
		
		Connection conn = null;
        PreparedStatement passSearchStatement = null;
        ResultSet passQueryResult = null;

        String dbUrl = "jdbc:mysql://mysql.cs.iastate.edu:3306/db30922";
        String dbUser = "u30922";
        String dbPass = "FPHZ44MveU";

        //attempt to update password table
        try
        {
        	conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            passSearchStatement = conn.prepareStatement(command);
            passQueryResult = passSearchStatement.executeQuery();
            ResultSetMetaData rsmd = passQueryResult.getMetaData();

            //DEBUG
            System.out.println("Executed query, retrieving data.");
            
            while(passQueryResult.next())
            {
            	sendToSocket(getColumns(passQueryResult, rsmd));
            }
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to connect to database or while querying.");
        	e.printStackTrace();
        }
        
        //closing open connections
        try
        {
        	if (passQueryResult != null)
        	{
        		passQueryResult.close();
        	}
        	if (passSearchStatement != null)
        	{
        		passSearchStatement.close();
        	}
        	if (conn != null)
        	{
        		conn.close();
        	}
        }
        catch (SQLException e)
        {
        	System.out.println("Exception occurred trying to close sql connections.");
        	e.printStackTrace();
        }
	}
	
	public void sendToSocket(String toSocket) throws IOException
	{
		OutputStreamWriter osw = new OutputStreamWriter(this.s.getOutputStream());
		BufferedWriter writer = new BufferedWriter(osw);
		writer.write(toSocket);
		writer.newLine();
		writer.flush();
		System.out.println("Socket Info: " + toSocket);
	}
	public void closeSocket() throws IOException
	{
		this.s.close();
	}
} // end of class ClientHandler
