
public class Child extends Person
{
	String parentID;
	
	public Child(String s1, String s2, String s3, String parentID)
	{
		super(s1, s2, s3);
		this.parentID = parentID;
	}
	
	public String getParent()
	{
		return parentID;
	}
}
