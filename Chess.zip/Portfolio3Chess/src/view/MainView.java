/**
 * Our main GUI program displays our application.
 */

package view;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainView extends Application
{
   @Override
   public void start(Stage primaryStage)
   {
      // Initialize display components.
      Group root = new Group();
      Scene scene = new Scene(root, 1280, 720);

      // Initialize a MainController.
      MainController controller = new MainController();

      // Add mainController.
      root.getChildren().addAll(controller);

      // Pin the root to scene and display it.
      primaryStage.setScene(scene);
      primaryStage.show();
      
      // Properly terminate the application if the user presses the "X" window button.
      primaryStage.setOnCloseRequest(event ->
      {
         controller.closeApplication();
      });

      /*
       * See how much nicer the lambda expression above looks?
       * 
      stage.setOnCloseRequest(new EventHandler<WindowEvent>()
      {
         public void handle(WindowEvent we)
         {
            controller.closeApplication();
         }
      });
      */

      // Set the title of the application.
      primaryStage.setTitle("Portfolio 3 - Chess");

      // Go to the first screen.
      controller.goToLoginScreen();

   }

   /**
    * This method is actually not used in a correctly deployed JavaFX application. Instead, the start method above is called. This main serves as a fallback in
    * case of improper configuration.
    * 
    * For whatever reason, Eclipse continues to use this instead of the start as the Java API says should be utilized...
    */
   public static void main(String[] args)
   {
      launch(args);
   }
}
