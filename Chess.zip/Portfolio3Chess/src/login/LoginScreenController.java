/**
 * This program is our handler for LoginScreen.fxml.
 */

package login;

import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.text.Text;
import framework.AbstractScreenController;
import framework.ControlledScreen;
import view.MainController;

public class LoginScreenController implements ControlledScreen
{
   // So we can set the screen's parent later on.
   MainController parentController;

   // FXML components.
   @FXML
   //private Text testLabel;
   private Label testLabel;
   
   @FXML
   private Button letsPlayButton;

   /**
    * Initializes the controller class. Automatically called after the FXML file has been loaded.
    */
   @FXML
   public void initialize()
   {
      // Event handlers for buttons.
      // The arrow means lambda expression in Java.
      // Lambda expressions allow you to create anonymous methods, which is perfect for eventHandling.
      testLabel.setOnMouseClicked(event ->
      {
         String currentText = testLabel.getText();
         String originalText = "Click me. Go on, I dare you.";
         String firstClick = "It works!!! Now stop poking me!";
         String subsequentClicks = "It's not funny.";
         
         if (currentText.equals(originalText))
            testLabel.setText(firstClick);
         else
            testLabel.setText(subsequentClicks);
      });
      
      letsPlayButton.setOnMouseClicked(event ->
      {
         parentController.goToGameBoardScreen();
      });
   }
   
   /**
    * Button handler for do something.
    * Just showing another neat way event handling can be done in JavaFX.
    * Notice how this is pinned in the FXML. We never make an explicit call to the button, nor do we even know the calling object.
    */
   @FXML
   private void doSomething()
   {
      testLabel.setText("Something has been done.");
   }
   
   @FXML
   private void activateAlert()
   {
	   TextInputDialog dialog = new TextInputDialog("Put in your username, fool");
	   dialog.setTitle("Text Input Dialog");
	   dialog.setHeaderText("Put some text below");
	   dialog.setContentText("Please enter your user:");

	   // Traditional way to get the response value.
	   Optional<String> result = dialog.showAndWait();
	   if (result.isPresent()){
	       System.out.println("Your name: " + result.get());
	   }
   }
   
   /**
    * Button handler for do something else.
    * As you can see, you can pin an event to the unknown call to extract a reference to the source object.
    * @param event This will be automagically passed when an FXML element calls this subject.
    */
   @FXML
   private void doSomethingElse(ActionEvent event)
   {
      testLabel.setText("Why, you pesky little " + event.getSource().getClass().getSimpleName() + "!");
   }

   /**
    * This method will allow for the injection of each screen's parent.
    */
   @Override
   public void setScreenParent(AbstractScreenController screenParent)
   {
      parentController = (MainController) screenParent;
   }
}
