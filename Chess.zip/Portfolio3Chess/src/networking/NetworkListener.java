/**
 * @author Anish Kunduru
 * 
 * This class listens for an incoming message and parses it appropriately.
 */

package networking;

import gameBoard.GameBoardScreenController;

import java.io.IOException;
import java.io.ObjectInputStream;

import javafx.application.Platform;
import server.Move;
import singleton.MainModel;

public class NetworkListener extends Thread
{
   private ObjectInputStream input;

   private boolean run; // To start and stop the thread.

   /**
    * Constructor creates a new listener thread.
    * 
    * @param input The input stream of the socket the server is connected to.
    */
   public NetworkListener(ObjectInputStream input)
   {
      // Initalize private state vars.
      this.input = input;
   }

   /**
    * Starts the listener thread.
    */
   public void run()
   {
      run = true; // Loop control var.

      try
      {
         // DEBUG
         System.out.println("Listener thread started.");

         // See if gameID is taken.
         boolean isGameIDTaken = (Boolean) input.readObject();

         if (isGameIDTaken)
         {
            end();

            // TODO Let the user know that ID is already taken.
            System.out.println("That game ID is already taken.");
         }
         else
         {
            // DEBUG
            System.out.println("That gameID is okay!");
         }

         // Let user know if they are a black player.
         boolean isBlack = (Boolean) input.readObject();

         // DEBUG
         System.out.println("Boolean isBlack: ");
         
         // TODO: Figure out way that we don't have to put thread to sleep.
         Thread.sleep(1000); // Put thread to sleep so that we have enough time to set the current controller.

         if (isBlack)
         {
            MainModel.getModel().currentControllerData().getGameBoardScreenController().setPlayer("black");

            // DEBUG
            System.out.println("Player has been set black.");
         }
         else
         {
            MainModel.getModel().currentControllerData().getGameBoardScreenController().setPlayer("white");

            // DEBUG
            System.out.println("Player has been set white.");
         }
      }
      catch (IOException | ClassNotFoundException e)
      {
         System.out.println("Error setting gameID/player.");
      }
      catch (InterruptedException e)
      {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }

      while (run)
      {
         try
         {
            Move move = (Move) input.readObject();
            String message = (String) input.readObject();
            
            // DEBUG
            System.out.println(message);
            
            GameBoardScreenController controller = MainModel.getModel().currentControllerData().getGameBoardScreenController();

            // For JavaFX thread safety:
            Platform.runLater(() ->
            {
               controller.move(controller.getChessSquare(move.getFromCol(), move.getFromRow()), controller.getChessSquare(move.getToCol(), move.getToRow()));
            });
            controller.nextPlayer();

            // controller.move(controller.getChessSquare(move.getFromRow(), move.getFromCol()), controller.getChessSquare(move.getToRow(), move.getToCol()));
            // if(message.equals("next player"))
            // controller.nextPlayer();
         }
         catch (IOException | ClassNotFoundException e)
         {
            System.out.println("The connection has been terminated: " + e.getMessage());
            run = false; // Break loop.
         }
      } // End while.
   }

   /**
    * Stops the listener thread by flipping the boolean.
    */
   public void end()
   {
      run = false;
   }
}
