/**
 * @author Anish Kunduru
 * 
 * This is the client side networking class that is called by a screen to initiate a connection to the server.
 */

package networking;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import server.Move;
import server.ServerMessage;
import singleton.MainModel;

public class Networking
{
   private Socket socket; // What we will listen on.
   
   // For the data that will be flowing back and forth.
   private ObjectInputStream input;
   private ObjectOutputStream output;
   
   // Listening thread waits for server message.
   private NetworkListener listener;
   
   // PUBLIC CONSTANTS THAT WILL NEED TO BE UPDATED WHEN SERVER FIELDS CHANGE.
   public final String SERVER_ADDRESS = "localhost";
   public final int SERVER_PORT = 1444;
   
   /**
    * Constructor creates a new Networking object and passes initial parameters to the server.
    * 
    * @param gameID A String that represents the game that the client wishes to join.
    */
   public Networking(String gameID)
   {
      // Try and connect to the server.
      try
      {
         socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
      }
      catch (IOException ioe)
      {
         System.out.println("There was an error connection to the server: " + ioe);
      }
      
      // Initialize streams.
      try
      {
         output = new ObjectOutputStream(socket.getOutputStream());
         input = new ObjectInputStream(socket.getInputStream());
         
         // DEBUG
         System.out.println("Created client I/O streams!");
      }
      catch (IOException ioe)
      {
         System.out.println("Exception creating I/O streams: " + ioe);
      }
      
      // Initialize server side calls to set gameID.
      try
      {
         output.writeObject(gameID);
         
         // DEBUG
         System.out.println("Set gameID as: " + gameID);
         
//         // See if gameID is taken.
//         boolean isGameIDTaken = input.readBoolean();
//         
//         if (!isGameIDTaken)
//         {
//            close();
//            
//            // TODO Let the user know that ID is already taken.
//            System.out.println("That game ID is already taken.");  
//         }
//         else
//         {
//            // DEBUG
//            System.out.println("That gameID is okay!");
//         }
//         
//         // TODO Let user know if they are a black player.
//         boolean isBlack = input.readBoolean();
//         
//         // DEBUG
//         System.out.println("Boolean isBlack: ");
//         
//         if (isBlack)
//         {
//            MainModel.getModel().currentControllerData().getGameBoardScreenController().setPlayer("black");
//            
//            // DEBUG
//            System.out.println("Player has been set black.");
//         }
//         else
//         {
//            MainModel.getModel().currentControllerData().getGameBoardScreenController().setPlayer("white");
//            
//            // DEBUG
//            System.out.println("Player has been set white.");
//         }
      }
      catch (IOException ioe)
      {
         System.out.println("Error sending gameID to server: " + ioe);
         close(); // Shut it down, there is nothing else we can do. This will also make calls to shut down the chat listener thread.
      }
      
      // Initialize the thread to listen from the server and start it.
      listener = new NetworkListener(input);
      listener.start();
   }
   
   /**
    * Closes out the I/O streams, socket, and sets the NetworkListener run boolean to false by calling its end() method.
    */
   private void close()
   {
      try
      {
         socket.close();
         input.close();
         output.close();
      }
      catch (IOException ioe)
      {
         System.out.println("Error closing I/O streams: " + ioe);
      }
      
      listener.end();
   }
   
   /**
    * Writes a message to the object buffer (socket stream).
    * 
    * @param move A move object that represents the details of the move that the player wishes to make.
    * @param message A string message that you can use to send messages to both users at once (append to textArea, for example).
    * @return True if the message was successfully sent; false if something failed.
    */
   public boolean bufferMove(Move move, String message)
   {
      // Check if client is still connected.
      if (!socket.isConnected())
      {
         close();
         return false;
      }
      
      // Write to buffer.
      try
      {
         // Wrap in ServerMessage type before sending.
         ServerMessage serverMessage = new ServerMessage(ServerMessage.Type.MOVE, move);
         output.writeObject(serverMessage);
         output.writeObject(message);         
      }
      catch (IOException ioe)
      {
         System.out.println("I/O error while attempting to send the ServerMessage: " + ioe);
      }
      
      // Implied else.
      return true;
   }
   
   /**
    * Send a logout type ServerMessage to the buffer, close the streams, and end the listener thread.
    */
   public void end()
   {
      // Send logout message.
      try
      {
         output.writeObject(new ServerMessage(ServerMessage.Type.LOGOUT, null));
      }
      catch (IOException ioe)
      {
         System.out.println("I/O error while sending logout request to server: " + ioe);
      }
      
      // Shut down this and related NetworkListener.
      close();
   }
}
