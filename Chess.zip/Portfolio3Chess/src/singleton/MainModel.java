/**
 * @author Anish Kunduru
 * 
 * The purpose of this program is to have one central model for data that needs to be passed among screens.
 * This utilizes a software design pattern called the singleton pattern.
 * We separate each controller's data into a new submodel that will be implemented in this calss.
 */

package singleton;

public class MainModel
{
   // Create singleton.
   private final static MainModel model = new MainModel();
   
   /**
    * @return The current instance of MainModel.
    */
   public static MainModel getModel()
   {
      return model;
   }
   
   // Instantiate data classes to store information.
   private ControllerData controllerData = new ControllerData();
   
   /**
    * @return The current instance of ControllerData.
    */
   public ControllerData currentControllerData()
   {
      return controllerData;
   }
}
