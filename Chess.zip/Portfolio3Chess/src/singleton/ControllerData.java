/**
 * @author Anish Kunduru
 * 
 * The purpose of this program is to store a reference to the current controller so that other threads can set public state data.
 */

package singleton;

import view.MainController;
import gameBoard.GameBoardScreenController;
import login.LoginScreenController;

public class ControllerData
{
   // Check current controller.
   String currentController;
   
   // All possible controllers.
   LoginScreenController loginScreenController;
   GameBoardScreenController gameBoardScreenController;
   
   
   /**
    * Default constructor to use in singleton.
    */
   public ControllerData()
   {
   }
   
   /**
    * Set the current controller so that it can be accessed by other pages.
    * 
    * @param currentController The currently active controller.
    */
   public void setCurrentController(String currentController)
   {
      this.currentController = currentController;
   }
   
   /**
    * Lets you know what the current controller is as set by the MainController.
    * 
    * @return A String representing the current controller.
    */
   public String getCurrentController()
   {
      return currentController;
   }
   
   /**
    * Allows you to set a loginScreenController.
    * 
    * @param controller The controller that you want to assign.
    * @return True if the passed controller was set; false if it was determined not to be a LoginScreenController.
    */
   public boolean setLoginScreenController(LoginScreenController controller)
   {
      if (controller instanceof LoginScreenController)
      {
         loginScreenController = controller;
         return true;
      }
      
      // Implied else.
      return false;
   }
   
   /**
    * @return LoginScreenController if it is the currently active screen. Otherwise you will get a null.
    */
   public LoginScreenController getLoginController()
   {
      if (currentController.equals(MainController.LOGIN))
         return loginScreenController;
      else
         return null;
   }
   
   /**
    * Allows you to set a gameBoardScreenController.
    * 
    * @param controller The controller that you want to assign.
    * @return True if the passed controller was set; false if it was determined not to be a GameBoardScreenController.
    */
   public boolean setGameBoardScreenController(GameBoardScreenController controller)
   {
      if (controller instanceof GameBoardScreenController)
      {
         gameBoardScreenController = controller;
         return true;
      }
      
      // Implied else.
      return false;
   }
   
   /**
    * @return GameBoardScreenController it if is the currently active screen. Otherwise, you will get a null.
    */
   public GameBoardScreenController getGameBoardScreenController()
   {
      if (currentController.equals(MainController.GAME_BOARD))
         return gameBoardScreenController;
      else
         return null;
   }
}
