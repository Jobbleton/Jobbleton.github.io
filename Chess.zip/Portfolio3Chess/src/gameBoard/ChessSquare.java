/**
 * This class represents a custom chessPiece so that we can keep track of where a piece is in the grid.
 */

package gameBoard;

import javafx.scene.control.Button;
import javafx.scene.image.Image;

public class ChessSquare extends Button
{
	// State data
	private String pieceName; // To set type.
	private String owner;

	// To set position on board.
	int row;
	int column;
	boolean moved;
	
	static final Image blackbishopImg = new Image("gameBoard\\images\\blackbishop.png");
	static final Image blackkingImg = new Image("gameBoard\\images\\blackking.png");
	static final Image blackknightImg = new Image("gameBoard\\images\\blackknight.png");
	static final Image blackpawnImg = new Image("gameBoard\\images\\blackpawn.png");
	static final Image blackqueenImg = new Image("gameBoard\\images\\blackqueen.png");
	static final Image blackrookImg = new Image("gameBoard\\images\\blackrook.png");
	static final Image whitebishopImg = new Image("gameBoard\\images\\whitebishop.png");
	static final Image whitekingImg = new Image("gameBoard\\images\\whiteking.png");
	static final Image whiteknightImg = new Image("gameBoard\\images\\whiteknight.png");
	static final Image whitepawnImg = new Image("gameBoard\\images\\whitepawn.png");
	static final Image whitequeenImg = new Image("gameBoard\\images\\whitequeen.png");
	static final Image whiterookImg = new Image("gameBoard\\images\\whiterook.png");
	static final Image emptyImg = new Image("gameBoard\\images\\empty.png");
	
	/**
	 * Constructor that initializes a custom button object using passed data.
	 * 
	 * @param pieceName The name of the piece you want to create (as defined in gameBoard.images).
	 * @param row The row that this piece will be located.
	 * @param column The column that this piece will be located.
	 */
	public ChessSquare(String pieceName, int row, int column)
	{
		if (!pieceName.equals("empty"))
		{
			switch(pieceName)
			{
			//getting image file
			case "blackbishop":
			case "blackking":
			case "blackknight":
			case "blackpawn":
			case "blackqueen":
			case "blackrook":
			case "whitebishop":
			case "whiteking":
			case "whiteknight":
			case "whitepawn":
			case "whitequeen":
			case "whiterook":
				this.pieceName = pieceName;
				this.owner = pieceName.substring(0,5);
				break;
			default:
				setPiece(pieceName);
				//DEBUG
				System.out.println("error has occurred when selecting piece");
				break;
			}
		}
		else
		{
			this.pieceName = "empty";
			this.owner = pieceName.substring(0,5);
		}
		this.row = row;
		this.column = column;
		moved = false;
	}
	
	public Image getImage()
	{
		switch(pieceName)
		{
		//getting image file
		case "blackbishop":
			return blackbishopImg;
		case "blackking":
			return blackkingImg;
		case "blackknight":
			return blackknightImg;
		case "blackpawn":
			return blackpawnImg;
		case "blackqueen":
			return blackqueenImg;
		case "blackrook":
			return blackrookImg;
		case "whitebishop":
			return whitebishopImg;
		case "whiteking":
			return whitekingImg;
		case "whiteknight":
			return whiteknightImg;
		case "whitepawn":
			return whitepawnImg;
		case "whitequeen":
			return whitequeenImg;
		case "whiterook":
			return whiterookImg;
		case "empty":
			//DEBUG
			//System.out.println("piece is empty, showing no image");
			return emptyImg;
		default:
			//DEBUG
			System.out.println("piece is empty or an error, showing no image");
			return null;
		}
	}
	
	//sets piece name which subsequently sets the owner for ease of access
	public void setPiece(String newPieceName)
	{
		pieceName = newPieceName;
		owner = pieceName.substring(0,5);
		moved = true;
	}
	
	public String toString()
	{
		String informalPieceName;
		switch(pieceName.substring(5))
		{
		case "pawn":
		case "rook":
		case "knight":
		case "bishop":
		case "queen":
		case "king":
			informalPieceName = "" + Character.toUpperCase(owner.charAt(0)) + owner.substring(1) + " " +
					Character.toUpperCase(pieceName.substring(5).charAt(0)) + pieceName.substring(6) + " " +
					"at" + " " + row + " " + column; 
			break;
		case "":
			informalPieceName = "Empty at" + " " + row + " " + column;
			break;
		default:
			informalPieceName = "Error, improper piece selected";
			break;
		}
		return informalPieceName;
	}

	public void setPlace(int rowIn, int colIn)
	{
		row = rowIn;
		column = colIn;
	}
	
	public int getX()
	{
		return row;
	}
	public int getY()
	{
		return column;
	}
	public String getPieceName()
	{
		return pieceName;
	}
	public String getOwner()
	{
		return owner;	
	}
	public boolean hasMoved()
	{
		return moved;
	}
	
	public static Image getEmptyImage()
	{
		return emptyImg;
	}
}
