package gameBoard;

import javafx.scene.image.Image;

//
//DEPRECATED
//

public class Knight extends ChessSquare
{

	static final Image blackknightImg = new Image("gameBoard\\images\\blackknight.png");
	
	public Knight(String pieceName, int row, int column) {
		super(pieceName, row, column);
		// TODO Auto-generated constructor stub
	}

	private boolean isValidKnightMove(ChessSquare from, ChessSquare to)
	{
		//DEBUG
		//System.out.println((from.getX()-to.getX()+from.getY()-to.getY())%2);
		if(Math.abs((from.getX()-to.getX()+from.getY()-to.getY())%2)==1)
		{
			if(Math.abs(from.getX()-to.getX()) > 2)
			{
				//DEBUG
				//System.out.println("error on x");
				return false;
			}
			if(Math.abs(from.getY()-to.getY()) > 2)
			{
				//DEBUG
				//System.out.println("error on y");
				return false;
			}
			return true;
			//return GameBoardScreenController.move(from,to);
		}
		else
		{
			//DEBUG
			//System.out.println("error on else");
			return false;
		}
	}
}
