package gameBoard;

import javafx.scene.layout.GridPane;

//
//DEPRECATED
//

public class ChessMove
{
	ChessSquare from, to;
	String player;
	GridPane game;
	public ChessMove(GridPane gameGrid, ChessSquare fromPiece, ChessSquare toPiece, String playerAttemptingToMove)
	{
		from = fromPiece;
		to = toPiece;
		player = playerAttemptingToMove;
		game = gameGrid;
	}
	
	public boolean isValidMove()
	{
		//there first selection should be their piece
		if(!isTheirPiece())
		{
			return false;
		}
		else
		{
			//their second selection should be any location not owned by them
			if(toTheirPiece())
			{
				return false;
			}
			else
			{
				//if the piece they slected and the location they're going to
				//are both proper, continue to more specific checks
				String pieceTitle = from.getPieceName().substring(5);
				switch(pieceTitle)
				{
					case "pawn":
						if(isPawnFirstMove())
						{
							
						}
						if(enPassant())
						{
							
						}
						break;
					case "rook":
						break;
					case "knight":
						break;
					case "bishop":
						break;
					case "queen":
						break;
					case "king":
						break;
				}
			}
		}
		
		//returns true if all other conditions pass
		return true;
	}
	
	private boolean isTheirPiece()
	{
		return from.getOwner().equals(player);
	}
	
	private boolean toTheirPiece()
	{
		return to.getOwner().equals(player);
	}
	
	private boolean isPawnFirstMove()
	{
		return true;
	}
	
	private boolean enPassant()
	{
		return true;
	}
}