/**
 * This program is our handler for GameBoardScreenController.fxml.
 */

package gameBoard;

import networking.Networking;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import server.Move;
import server.Move.Piece;
import view.MainController;
import framework.AbstractScreenController;
import framework.ControlledScreen;
import framework.Destroyable;

public class GameBoardScreenController implements ControlledScreen, Destroyable
{
	// So we can set the screen's parent later on.
	MainController parentController;
	
	// So we can properly terminate networking later on.
	Networking networking;

	// FXML components.
	@FXML
	private GridPane gameGrid;
	@FXML
	private TextArea playLog;
	
	private ChessSquare lastPieceSelected = null;
	private String currentPlayer = null;
	
	private String thisPlayer = null;
	
	boolean endGame;
	
	/**
	 * Initializes the controller class. Automatically called after the FXML file has been loaded.
	 */
	@FXML
	public void initialize()
	{
		currentPlayer = "black";
		endGame = false;
		// Joe: An example of how we can easily communicate with the user:
		playLog.appendText("> Welcome to Chess.\n");
		playLog.appendText("> Good luck!\n");
		
		// Initialize a networking connection to make sure it works. USING HARDCODED VALUES FOR NOW.
		networking = new Networking("testGame");
		
		initializeGameGrid();
		//DEBUG
		//Move move = new Move(Piece piece, boolean isBlack, int fromRow, int fromCol, int toRow, int toCol);
		//networking.bufferMove(Move move, String message)
	}

	/**
	 * A private helper method to instantiate ImageViews in the gameGrid().
	 */
	private void initializeGameGrid()
	{
		// Nested loops to iterate over pane.
		for (int c = 0; c < gameGrid.getRowConstraints().size(); c++)
		{
			for (int r = 0; r < gameGrid.getColumnConstraints().size(); r++)
			{
				ChessSquare chessSquare = null;		
				//this is brilliant and very good at code reducing in my opinion
				//starts on white side
				String color = "white";
				int tempRow = r;
				//if the side is black, it flips it
				if(r > (gameGrid.getRowConstraints().size()/2))
				{
					color = "black";
					tempRow = 7-r;
				}
				//back row
				if(tempRow == 0)
				{
					if(c==0 || c==7)
					{
						chessSquare = new ChessSquare(color + "rook",c,r);
					}
					else if(c==1 || c==6)
					{
						chessSquare = new ChessSquare(color + "knight",c,r);
					}
					else if(c==2| c==5)
					{
						chessSquare = new ChessSquare(color + "bishop",c,r);
					}
					else if(c==3)
					{
						chessSquare = new ChessSquare(color + "queen",c,r);
					}
					else if(c==4)
					{
						chessSquare = new ChessSquare(color + "king",c,r);
					}
				}
				//front row is all pawns
				else if(tempRow == 1)
				{
					chessSquare = new ChessSquare(color+"pawn",c,r);
				}
				else
				{
					chessSquare = new ChessSquare("empty",c,r);
				}
				
				//at every diagonal square set background to
				//(slightly different) black or white
				if ((r + c) % 2 == 1)
				{
					chessSquare.setStyle("-fx-background-color: #222222;");
				}
				else
				{
					chessSquare.setStyle("-fx-background-color: #DDDDDD;");
				}
				chessSquare.setGraphic(new ImageView(chessSquare.getImage()));
				chessSquare.setMinSize(75,75);
				setEventHandler(chessSquare);
				GridPane.setRowIndex(chessSquare,r);
				GridPane.setColumnIndex(chessSquare,c);
				gameGrid.add(chessSquare, c, r);
			} // End column loop.
		} // End row loop.
	}
	
	/**
	 * A private helper method to pin event handlers to the ChessSquares passed to it.
	 * 
	 * @param piece - The custom ChessSquare object that you wish to assign a handler to.
	 */
	private void setEventHandler(ChessSquare piece)
	{
		piece.setOnMousePressed(event -> {
			if(lastPieceSelected == null)
			{
				lastPieceSelected = piece;
				playLog.appendText(piece.toString() + " selected first\n");
			}
			else if(lastPieceSelected == piece)
			{
				lastPieceSelected = null;
				playLog.appendText(piece.toString() + " deselected\n");
			}
			else
			{
				playLog.appendText(piece.toString() + " selected second\n");
				
				if(isValidMove(lastPieceSelected, piece))
				{
					boolean isBlack = false;
					if(thisPlayer.equals("black"))
					{
						isBlack = true;
					}
					Piece pieceEnum = null;
					String pieceTitle = lastPieceSelected.getPieceName().substring(5);
					switch(pieceTitle)
					{
					case "pawn":
						pieceEnum = Piece.PAWN;
						break;
					case "rook":
						pieceEnum = Piece.ROOK;
						break;
					case "knight":
						pieceEnum = Piece.KNIGHT;
						break;
					case "bishop":
						pieceEnum = Piece.BISHOP;
						break;
					case "queen":
						pieceEnum = Piece.QUEEN;
						break;
					case "king":
						pieceEnum = Piece.KING;
						break;
					default:
						pieceEnum = Piece.PAWN;
						break;
					}

					Move move = new Move(pieceEnum, isBlack, lastPieceSelected.getY(), lastPieceSelected.getX(), piece.getY(), piece.getX());
					networking.bufferMove(move, "next player");
					nextPlayer();
					playLog.appendText("> valid move, next player's turn\n");
				}
				else
				{
					playLog.appendText("> invalid move\n");
				}
				lastPieceSelected = null;
			}
				
		});
	}

	//series of checks to validate moves
	private boolean isValidMove(ChessSquare from, ChessSquare to)
	{
		if(!currentPlayer.equals(thisPlayer)) return false;
		//there first selection should be their piece
		if(!isTheirPiece(from, thisPlayer))
		{
			return false;
		}
		else
		{
			//their second selection should be any location not owned by them
			if(toTheirPiece(to, thisPlayer))
			{
				return false;
			}
			else
			{
				//if the piece they slected and the location they're going to
				//are both proper, continue to more specific checks
				String pieceTitle = from.getPieceName().substring(5);
				switch(pieceTitle)
				{
				case "pawn":
					return isValidPawnMove(from, to);
				case "rook":
					//DEBUG
					//System.out.println("rook test");
					return isValidRookMove(from, to);
				case "knight":
					return isValidKnightMove(from, to);
				case "bishop":
					return isValidBishopMove(from, to);
				case "queen":
					return isValidQueenMove(from, to);
				case "king":
					return isValidKingMove(from, to);
				}
			}
		}

		//returns true if all other conditions pass
		return true;
	}

	//checks for piece ownership
	private boolean isTheirPiece(ChessSquare from, String player)
	{
		return from.getOwner().equals(player);
	}

	private boolean toTheirPiece(ChessSquare to, String player)
	{
		return to.getOwner().equals(player);
	}

	//checks for pawn moves
	private boolean isValidPawnMove(ChessSquare from, ChessSquare to)
	{
		//black piece case
		if(from.getOwner().equals("black"))
		{
			if(from.getY() - to.getY() == 2)
			{
				//DEBUG
				//System.out.println("row 6 black pawn");
				//DEBUG
				//System.out.println(getChessSquare(6,6).toString());

				if(from.getY() == 6)
				{
					//if a double move
					if(to.getY() == 4)
					{
						//if a two jump that is straight ahead
						if(from.getX() == to.getX())
						{
							//if there is a piece in front that is not empty
							//DEBUG
							//System.out.println((getChessSquare(5,from.getY())).getOwner());
							if(!(((getChessSquare(from.getX(),5)).getOwner()).equals("empty")))
							{
								return false;
							}
							else
							{
								return true;
							}
						}
						//a two jump that is not straight ahead
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			//if a single move
			if(from.getY() - to.getY() == 1)
			{
				//simple single forward motion
				if(from.getX() - to.getX() == 0)
				{
					if(!((to.getOwner()).equals("empty")))
					{
						return false;
					}
				}
				//diagonal capture
				else if((from.getX() - to.getX() == 1)||(from.getX() - to.getX() == -1))
				{
					if(!to.getOwner().equals("white"))
					{
						return false;
					}
				}
				//up by one, but an improper horizontal movement
				else
				{
					return false;
				}
			}
			//not a double move, single move, or single diagonal capture
			else
			{
				return false;
			}
			if(to.getY() == 0)
			{
				from.setPiece("blackqueen");
			}
			return true;
		}
		else if(from.getOwner().equals("white"))
		{
			if(to.getY() - from.getY() == 2)
			{
				//DEBUG
				//System.out.println("row 6 black pawn");
				//DEBUG
				//System.out.println(getChessSquare(6,6).toString());

				if(from.getY() == 1)
				{
					//if a double move
					if(to.getY() == 3)
					{
						//if a two jump that is straight ahead
						if(from.getX() == to.getX())
						{
							//if there is a piece in front that is not empty
							//DEBUG
							//System.out.println((getChessSquare(5,from.getY())).getOwner());
							if(!(((getChessSquare(from.getX(),2)).getOwner()).equals("empty")))
							{
								return false;
							}
							else
							{
								return true;
							}
						}
						//a two jump that is not straight ahead
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			//if a single move
			if(to.getY() - from.getY() == 1)
			{
				//simple single forward motion
				if(from.getX() - to.getX() == 0)
				{
					if(!((to.getOwner()).equals("empty")))
					{
						return false;
					}
				}
				//diagonal capture
				else if((from.getX() - to.getX() == 1)||(from.getX() - to.getX() == -1))
				{
					if(!to.getOwner().equals("black"))
					{
						return false;
					}
				}
				//up by one, but an improper horizontal movement
				else
				{
					return false;
				}
			}
			//not a double move, single move, or single diagonal capture
			else
			{
				return false;
			}
			if(to.getY() == 7)
			{
				from.setPiece("whitequeen");
			}
			return true;
		}
		return false;
	}

	
	private boolean isValidRookMove(ChessSquare from, ChessSquare to)
	{
		//DEBUG
		//System.out.println(from.getX() + " " + from.getY());
		//System.out.println(to.getX() + " " + to.getY());
		
		//DEBUG
		//System.out.println(getChessSquare(to.getX(),to.getY()));
		
		//x is changing
		if(from.getX() != to.getX())
		{
			if(from.getY() != to.getY())
			{
				return false;
			}
			//moving on x, x changing, y still
			else
			{
				//positive x movement
				if((to.getX() - from.getX()) > 1)
				{
					for(int i = (from.getX() + 1); i < to.getX(); i++)
					{
						if(!((getChessSquare(i,from.getY()).getOwner()).equals("empty")))
							return false;
					}
				}
				//negative x movement
				else
				{
					for(int i = (to.getX() + 1); i < from.getX(); i++)
					{
						if(!((getChessSquare(i,from.getY()).getOwner()).equals("empty")))
							return false;
					}
				}
			}
		}
		//y changing, x still
		else
		{
			//positive y movement
			if((to.getY() - from.getY()) > 1)
			{
				for(int i = (from.getY() + 1); i < to.getY(); i++)
				{
					if(!((getChessSquare(from.getX(),i).getOwner()).equals("empty")))
						return false;
				}
			}
			//negative y movement
			else
			{
				for(int i = (to.getY() + 1); i < from.getY(); i++)
				{
					if(!((getChessSquare(from.getX(),i).getOwner()).equals("empty")))
						return false;
				}
			}
		}
		return true;
	}

	private boolean isValidKnightMove(ChessSquare from, ChessSquare to)
	{
		//DEBUG
		//System.out.println((from.getX()-to.getX()+from.getY()-to.getY())%2);
		if(Math.abs((from.getX()-to.getX()+from.getY()-to.getY())%2)==1)
		{
			if(Math.abs(from.getX()-to.getX()) > 2)
			{
				//DEBUG
				//System.out.println("error on x");
				return false;
			}
			if(Math.abs(from.getY()-to.getY()) > 2)
			{
				//DEBUG
				//System.out.println("error on y");
				return false;
			}
			return true;
		}
		else
		{
			//DEBUG
			//System.out.println("error on else");
			return false;
		}
	}

	private boolean isValidBishopMove(ChessSquare from, ChessSquare to)
	{
		//upleft downright
		if((from.getX() - to.getX()) == (from.getY() - to.getY()))
		{
			//DEBUG
			//System.out.println("upleft downright");
			if(from.getX() < to.getX())
			{
				//DEBUG
				//System.out.println("downright");
				for(int i = 1; i < (to.getX()-from.getX()); i++)
				{
					if(!((getChessSquare(from.getX()+i,from.getY()+i).getOwner()).equals("empty")))
						return false;
				}
				return true;
			}
			else
			{
				//DEBUG
				//System.out.println("upleft");
				for(int i = 1; i < (from.getX()-to.getX()); i++)
				{
					if(!((getChessSquare(from.getX()-i,from.getY()-i).getOwner()).equals("empty")))
						//DEBUG
						//System.out.println("upleft stoppage at " + (to.getX() + i) + " " + (to.getY() + i));
						return false;
				}
				return true;
			}
		}
		//upright downleft
		else if((from.getX() - to.getX()) == -(from.getY() - to.getY()))
		{
			//DEBUG
			//System.out.println("upright downleft");
			if(from.getX() > to.getX())
			{
				//DEBUG
				//System.out.println("upright");
				for(int i = 1; i < (to.getX()-from.getX()); i++)
				{
					if(!((getChessSquare(from.getX()+i,from.getY()-i).getOwner()).equals("empty")))
						return false;
				}
				return true;
			}
			else
			{
				//DEBUG
				//System.out.println("downleft");
				for(int i = 1; i < (from.getX()-to.getX()); i++)
				{
					if(!((getChessSquare(from.getX()-i,from.getY()+i).getOwner()).equals("empty")))
						return false;
				}
				return true;
			}
		}
		else
		{
			//DEBUG
			//System.out.println("not a diagonal");
			return false;
		}
	}
	
	private boolean isValidQueenMove(ChessSquare from, ChessSquare to)
	{
		return isValidRookMove(from, to) || isValidBishopMove(from, to);
	}
	
	private boolean isValidKingMove(ChessSquare from, ChessSquare to)
	{
		if(!(Math.abs(from.getX()-to.getX())<=1))
		{
			return false;
		}
		else if(!(Math.abs(from.getY()-to.getY())<=1))
		{
			return false;
		}
		else if(isLocationDangerous(to, from.getOwner()))
		{
			return false;
		}
		else
			return true;	
	}
	
	/**
	 * Move from one ChessSquare to another.
	 * 
	 * @param from The ChessSquare you wish to move from.
	 * @param to The ChessSquare you wish to move to.
	 * @return True if the move worked.
	 */
	public boolean move(ChessSquare from, ChessSquare to)
	{
		//flag for end game
		if(to.getPieceName().substring(5).equals("king"))
		{
			endGame = true;
		}
		to.setPiece(from.getPieceName());
		to.setGraphic(new ImageView(from.getImage()));
		from.setPiece("empty");
		from.setGraphic(new ImageView(ChessSquare.getEmptyImage()));
		return true; // Always true due to modifications to our code.
	}

	public ChessSquare getChessSquare(int x, int y)
	{
		ChessSquare toReturn = null;
		//DEBUG
		//System.out.println("before loop");
		for(Node piece : gameGrid.getChildren()) {
			try
			{
				if(GridPane.getRowIndex(piece) == y && GridPane.getColumnIndex(piece) == x)
				{
					toReturn = (ChessSquare) piece;
					//DEBUG
					//System.out.println("found a match");
					break;
				}
				//DEBUG
				//System.out.println("looped");
			}
			catch(NullPointerException e)
			{
				//DEBUG
				//System.out.println("null val for row and/or col");
			}
		}
		return toReturn;
	}
	
	private boolean isLocationDangerous(ChessSquare toCheck, String player)
	{
		//for each enemy piece,
		//flags locations they are able to go to as dangerous,
		//if the toCheck is on one of those squares,
		//returns true
		boolean[][] flag = new boolean[8][8];
		for(Node piece : gameGrid.getChildren())
		{
			try
			{
				ChessSquare suspectPiece = (ChessSquare) piece;
				if((suspectPiece.getOwner().equals("white") && player.equals("black"))||(suspectPiece.getOwner().equals("black") && player.equals("white")))
				{
					if(suspectPiece.getPieceName().equals("whitepawn"))
					{
						try{
						flag[suspectPiece.getX()-1][suspectPiece.getY()+1] = true;
						}
						catch(ArrayIndexOutOfBoundsException e){}
						try{
							flag[suspectPiece.getX()+1][suspectPiece.getY()+1] = true;
						}
						catch(ArrayIndexOutOfBoundsException e){}
					}
					else if(suspectPiece.getPieceName().equals("blackpawn"))
					{
						try{
						flag[suspectPiece.getX()-1][suspectPiece.getY()-1] = true;
						}
						catch(ArrayIndexOutOfBoundsException e){}
						try{
							flag[suspectPiece.getX()+1][suspectPiece.getY()-1] = true;
						}
						catch(ArrayIndexOutOfBoundsException e){}
					}
					else
					{
						String pieceTitle = suspectPiece.getPieceName().substring(5);
						switch(pieceTitle)
						{
						case "rook":
							for(int i = suspectPiece.getX()+1; i < 8; i++)
							{
								if(!getChessSquare(i,suspectPiece.getY()).getOwner().equals("empty"))
									flag[i][suspectPiece.getY()] = true;
								else
								{ 
									flag[i][suspectPiece.getY()] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1; i >= 0; i--)
							{
								if(!getChessSquare(i,suspectPiece.getY()).getOwner().equals("empty"))
									flag[i][suspectPiece.getY()] = true;
								else
								{
									flag[i][suspectPiece.getY()] = true;
									break;
								}
							}
							for(int i = suspectPiece.getY()+1; i < 8; i++)
							{
								if(!getChessSquare(suspectPiece.getX(),i).getOwner().equals("empty"))
									flag[suspectPiece.getX()][i] = true;
								else
								{
									flag[suspectPiece.getX()][i] = true;
									break;
								}
							}
							for(int i = suspectPiece.getY()-1; i >= 0; i--)
							{
								if(!getChessSquare(suspectPiece.getX(),i).getOwner().equals("empty"))
									flag[suspectPiece.getX()][i] = true;
								else
								{
									flag[suspectPiece.getX()][i] = true;
									break;
								}
							}
							break;

						case "knight":
							try{
								flag[suspectPiece.getX()+2][suspectPiece.getY()+1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+2][suspectPiece.getY()-1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-2][suspectPiece.getY()+1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-2][suspectPiece.getY()-1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+1][suspectPiece.getY()+2] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+1][suspectPiece.getY()-2] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-1][suspectPiece.getY()+2] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-1][suspectPiece.getY()-2] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							break;
						case "bishop":
							for(int i = suspectPiece.getX()+1, j = suspectPiece.getY()+1; i < 8 && j < 8; i++, j++)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()+1, j = suspectPiece.getY()-1; i < 8 && j >= 0; i++, j--)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1, j = suspectPiece.getY()+1; i >= 0 && j < 8; i--, j++)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1, j = suspectPiece.getY()-1; i >= 0 && j >= 0; i--, j--)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							break;
						case "queen":
							for(int i = suspectPiece.getX()+1, j = suspectPiece.getY()+1; i < 8 && j < 8; i++, j++)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()+1, j = suspectPiece.getY()-1; i < 8 && j >= 0; i++, j--)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1, j = suspectPiece.getY()+1; i >= 0 && j < 8; i--, j++)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1, j = suspectPiece.getY()-1; i >= 0 && j >= 0; i--, j--)
							{
								if(!getChessSquare(i,j).getOwner().equals("empty"))
									flag[i][j] = true;
								else
								{ 
									flag[i][j] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()+1; i < 8; i++)
							{
								if(!getChessSquare(i,suspectPiece.getY()).getOwner().equals("empty"))
									flag[i][suspectPiece.getY()] = true;
								else
								{ 
									flag[i][suspectPiece.getY()] = true;
									break;
								}
							}
							for(int i = suspectPiece.getX()-1; i >= 0; i--)
							{
								if(!getChessSquare(i,suspectPiece.getY()).getOwner().equals("empty"))
									flag[i][suspectPiece.getY()] = true;
								else
								{
									flag[i][suspectPiece.getY()] = true;
									break;
								}
							}
							for(int i = suspectPiece.getY()+1; i < 8; i++)
							{
								if(!getChessSquare(suspectPiece.getX(),i).getOwner().equals("empty"))
									flag[suspectPiece.getX()][i] = true;
								else
								{
									flag[suspectPiece.getX()][i] = true;
									break;
								}
							}
							for(int i = suspectPiece.getY()-1; i >= 0; i--)
							{
								if(!getChessSquare(suspectPiece.getX(),i).getOwner().equals("empty"))
									flag[suspectPiece.getX()][i] = true;
								else
								{
									flag[suspectPiece.getX()][i] = true;
									break;
								}
							}
							break;
						case "king":
							try{
								flag[suspectPiece.getX()][suspectPiece.getY()+1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+1][suspectPiece.getY()+1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+1][suspectPiece.getY()] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()+1][suspectPiece.getY()-1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()][suspectPiece.getY()-1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-1][suspectPiece.getY()-1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-1][suspectPiece.getY()] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							try{
								flag[suspectPiece.getX()-1][suspectPiece.getY()+1] = true;
							}
							catch(ArrayIndexOutOfBoundsException e){}
							break;
						}
					}
				}
			}
			catch(NullPointerException e)
			{
				//DEBUG
				//System.out.println("null val for row and/or col");
			}
			catch(ClassCastException e)
			{
				//DEBUG
				//System.out.println("Group casted by accident, skipping");
			}
		}
		return flag[toCheck.getX()][toCheck.getY()];
	}
	
	public void setPlayer(String player)
	{
		thisPlayer = player;
	}
	
	public void nextPlayer()
	{
		if(currentPlayer.equals("black"))
			currentPlayer = "white";
		else
			currentPlayer = "black";
	}
	
	/**
	 * This method will allow for the injection of each screen's parent.
	 */
	@Override
	public void setScreenParent(AbstractScreenController screenParent)
	{
		parentController = (MainController) screenParent;
	}
	
	/**
	 * This method will allow us to safely close thread elements when we are ready to leave the page.
	 */
   @Override
   public void onDestroy()
   {
      // DEBUG
      System.out.println("Destroying this controller...");
      
      // Close out networking.
      networking.end();
   }
}
