/**
 * @author Anish Kunduru
 * 
 * This program defines the different types of moves that a game can make.
 * We use a custom object to make it easier to determine state data.
 */

package server;

import java.io.Serializable;

public class Move implements Serializable
{
   // Implement serializable.
   private static final long serialVersionUID = -2566075742983906581L;
   
   public enum Piece
   {
     KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN 
   };
   
   // Object vars.
   private Piece pieceType;
   
   private boolean isBlack; // Which player is trying to make this move?
   
   private int fromRow;
   private int fromCol;
   private int toRow;
   private int toCol;
   
   /**
    * Constructor that creates a move object.1
    * 
    * @param piece The Move.Piece type that represents this chess piece.
    * @param isBlack True is the player is the black piece; false if he isn't.
    * @param fromRow The row that you are moving from.
    * @param fromCol The column that you are moving from.
    * @param toRow The row that you want to move to.
    * @param toCol The column that you want to move to.
    */
   public Move(Piece piece, boolean isBlack, int fromRow, int fromCol, int toRow, int toCol)
   {
      // Initialize vars.
      pieceType = piece;
      
      // Check validity and set to -1 if there was a problem (this will be checked in the server).
      this.fromRow = isValidPos(fromRow) ? fromRow : -1;
      this.fromCol = isValidPos(fromCol) ? fromCol : -1;
      this.toRow = isValidPos(toRow) ? toRow: -1;
      this.toCol = isValidPos(toCol) ? toCol : -1;
   }
   
   /**
    * Private helper method to make sure we were passed valid ints.
    * 
    * @param pos The row or column of a piece on the chess board.
    * @return True if a valid move; false otherwise.
    */
   private boolean isValidPos(int pos)
   {
      if (pos >= 0 || pos <= 7)
         return true;
      else
         return false;
   }
   
   /**
    * @return A Move.Piece enumeration.
    */
   public Piece getPiece()
   {
      return pieceType;
   }
   
   /**
    * @return The row that a piece is trying to move from.
    */
   public int getFromRow()
   {
      return fromRow;
   }
   
   /**
    * @return The column that a piece is trying to move from.
    */
   public int getFromCol()
   {
      return fromCol;
   }
   
   /**
    * @return The row that a piece is trying to move from.
    */
   public int getToRow()
   {
      return toRow;
   }
   
   /**
    * @return The column that a piece is trying to move from.
    */
   public int getToCol()
   {
      return toCol;
   }
   
   /**
    * @return True if this is the black player's move, false otherwise.
    */
   public boolean isBlack()
   {
      return isBlack;
   }
}
