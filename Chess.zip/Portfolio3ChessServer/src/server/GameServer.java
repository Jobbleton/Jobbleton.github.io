/**
 * @author Anish Kunduru
 * 
 * This class is the game server that will connect all the clients together.
 * It calls and starts a new ClientThread for every user that connects to it.
 */

package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class GameServer
{
   private static int clientID; // Iterate to keep a list of connected clients.
   private ArrayList<ClientThread> clients;
   private int serverPort; // Port number to listen to.
   private boolean run; // To start and stop the server.
   
   /**
    * Constructor to create a new GameServer.
    * 
    * @param portNumber The port that you want the server to listen on.
    */
   public GameServer(int portNumber)
   {
      serverPort = portNumber;
      clients = new ArrayList<ClientThread>();
      run = true;
      clientID = 0;
   }
   
   /**
    * Starts up the server.
    */
   public void start()
   {
      try
      {
         // Create the socket and wait for a request.
         ServerSocket serverSocket = new ServerSocket(serverPort);
         
         while (run)
         {
            // DEBUG
            System.out.println("Waiting for clients on port: " + serverPort + ".");
            
            // If you get a request, add it.
            Socket clientSocket = serverSocket.accept();
            
            // DEBUG
            System.out.println("Connection request made from a client user.");
            
            // Check to break before adding threads (avoid thread interrupt exceptions or hangs).
            if (!run)
               break;
            
            // Create and start the thread.
            ClientThread client = new ClientThread(clientSocket, clientID, this);
            clients.add(client);
            
            // DEBUG
            System.out.println("Created and added client: " + client.getClientID());
            
            // Iterate ID var.
            clientID++;
            
            // Start the previously created thread.
            client.start();
         } // End while.
         
         // Broke out of while loop. Shut it down...
         try
         {
            serverSocket.close();
            
            // Shut down the threads.
            for (ClientThread client : clients)
               client.close();
         }
         catch (IOException ioe)
         {
            // DEBUG
            System.out.println("Error closing the serverSocket: " + ioe);
         }
      }
      catch (IOException ioe)
      {
         System.out.println("Error creating the serverSocket or creating the clientSocket: " + ioe);
      }
   }
   
   /**
    * Stops the server by tripping the boolean.
    */
   public void stop()
   {
      run = false;
      
      // Break the loop by connecting to the socket.
      try
      {
         new Socket("localhost", serverPort);
         
      }
      catch (IOException ioe)
      {
         System.out.println("Error trying to stop the server: " + ioe);
      }
   }
   
   /**
    * To broadcast a message to the clients that are in the same game. This is run as a synchronized method because we want to prevent thread interference since this thread is visible to more than one thread. 
    * 
    * @param move A Move object that contains the attempted client move.
    * @param gameID The reference String for this game.
    * @param message The message that you wish to be broadcast along with.
    */
   public synchronized void broadcastMove(Move move, String gameID, String message)
   {
      // Loop in reverse and remove disconnected clients along the way.
      for (int i = clients.size(); --i >= 0;)
      {
         ClientThread client = clients.get(i);
               
         // Check if client is in room.
         if (gameID.equals(client.getGameID()))
         {
            // Buffer messages, dumping a client if it fails.
            if (!client.bufferMove(move, message))
            {
               clients.remove(i);
               
               // DEBUG
               System.out.println("Client: " + clientID + " has been disconnected");
            }
         }
      } // End for loop
   }
   
   /**
    * Make sure that this gameID isn't already being used.
    * 
    * @param gameID The gameID that the client wants to use.
    * @return The number of players currently with that gameID.
    */
   public synchronized int numPlayersInGame(String gameID)
   {
      int players = 0;
      
      for (ClientThread client : clients)
      {
         if (client.getGameID().equals(gameID))
            players++;
         
         // DEBUG
         System.out.println("Found: " + players + " with gameID: " + gameID + ".");
      }
      
      return players;
   }
   
   /**
    * To remove a client from the chat server. This is called when a client sends a logout message.
    * 
    * @param clientID The unique ID number that represents this client.
    */
   public synchronized void removeClient(int clientID)
   {
      // Scan the array until you find the clientID.
      
      for (int i = 0; i < clients.size(); i++)
      {
         ClientThread client = clients.get(i);
         
         if (client.getClientID() == clientID)
         {
            // TODO NOTE: WE MIGHT WANT TO LET THE OTHER CLIENT KNOW THAT THEIR TEAMMATE HAS DISCONNECTED.
            // WE CAN IGNORE THIS FOR NOW.
            
            clients.remove(i);
            break; // ///////////////////// found it, we can stop looping now ///////////////////
         }
      } // End for loop.
   }
   
   public static void main(String[] args)
   {
      // Start a new GameServer on port 1444.
      final int SERVER_PORT = 1444;
      
      GameServer server = new GameServer(SERVER_PORT);
      server.start();
   }
}
