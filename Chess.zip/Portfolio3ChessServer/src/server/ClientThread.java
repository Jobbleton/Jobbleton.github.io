/**
 * @author Anish Kunduru
 * 
 * This class represents a server-side thread for each client that is connect to the server.
 */

package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientThread extends Thread
{
   private Socket socket; // What we will listen on.
   
   // For our SeverMessage objects to come in and booleans to go out.
   private ObjectInputStream input;
   private ObjectOutputStream output;
   
   // To properly close the thread upon disconnect.
   private int clientID;
   // To know who to broadcast the message to.
   private String gameID;
   // To know which player it is.
   boolean isBlack;
   
   // For setting and getting from streams.
   private ServerMessage serverMessage;
   private String message;
   
   // Store reference of calling thread to remove myself upon logout.
   private GameServer parentServer;
   
   private boolean run; // To start and stop the thread.
   
   /**
    * Constructor creates a new client thread.
    * 
    * @param socket The socket that the client is operating on.
    * @param clientID The unique ID number that represents the client.
    * @param server The parent server (calling class) that has initiated this new thread.
    */
   public ClientThread(Socket socket, int clientID, GameServer server)
   {
      // Set state vars.
      this.clientID = clientID;
      this.socket = socket;
      parentServer = server;
      
      // DEBUG
      System.out.println("Creating I/O streams...");
      
      try
      {
         // Initialize streams.
         input = new ObjectInputStream(socket.getInputStream());
         output = new ObjectOutputStream(socket.getOutputStream());
         
         // Initialize gameID and isBlack (player type).
         gameID = (String) input.readObject();
         
         int numPlayers = server.numPlayersInGame(gameID);
         
         // Check if gameID already taken.
         boolean isGameIDTaken;
         
         if (numPlayers >= 2)
         {
            isGameIDTaken = true;
            output.writeObject(isGameIDTaken);
            
            // DEBUG
            System.out.println("Sent isGameIDTaken: true");
         }
         else
         {
            isGameIDTaken = false;
            output.writeObject(isGameIDTaken);
            
            // DEBUG
            System.out.println("Sent isGameIDTaken: false");
         }
         
         // Let user know if he is black or white player.
         isBlack = (numPlayers == 0) ? true : false;
         output.writeObject(isBlack);
         
         // DEBUG
         System.out.println("A player connected in with gameID: " +  gameID + ". He is a black player: " + isBlack + ".");
      }
      catch (IOException ioe)
      {
         System.out.println("Exception creating I/O streams: " + ioe);
      }
      catch (ClassNotFoundException cnfe)
      {
         System.out.println("There was an issue reading the gameID from the input stream: " + cnfe);
      }
   }
   
   /**
    * To start the thread.
    */
   public void run()
   {
      run = true; // Loop using blocking calls.
      
      while (run)
      {
         try
         {
            serverMessage = (ServerMessage) input.readObject();
            message = (String) input.readObject();            
         }
         catch (IOException | ClassNotFoundException e)
         {
            // NOTE: If this is thrown, we probably weren't passed the correct object type.

            System.out.println(clientID + " had an I/O stream exception: " + e);
            break; // //////////////////// So we don't lock up the thread. ////////////////////////////
         }
         
         // Parse enum.
         switch(serverMessage.getMessageType())
         {
            case LOGOUT:
            {
               run = false; // Stop running.
               
               // DEBUG
               System.out.println(clientID + " has disconnected.");
               
               //TODO: AT A LATER DATE, YOU MIGHT WANT TO LET OTHER USERS KNOW THAT YOU HAVE DISCONNECTED.
               
               break;
            }
            case MOVE:
            {
               // Extract the move.
               Move move = serverMessage.getMove();
               
               parentServer.broadcastMove(move, gameID, message);
            }
         } // End switch.
      } // End while.
      
      // Ended loop, must have logged out.
      parentServer.removeClient(clientID);
      close();
   }
   
   /**
    * Helper method to assist in closing the I/O streams after client disconnect or fatal error.
    */
   public void close()
   {
      try
      {
         output.close();
         input.close();
         socket.close();
      }
      catch (IOException ioe)
      {
         // NOTE: There probably isn't anything that we can do if this happens...
         System.out.println("There was an error closing the streams AND/OR socket: " + ioe);
      }
   }
   
   /**
    * Write a move and other related information to the object buffer (socket stream)
    * 
    * @param isValidMove True if the move was deemed valid; false if it wasn't.
    * @param move A move object representing the move that the client wants to make.
    * @param message The message as deemed by this class.
    * @return True if the the arguments were successfully sent; false if something failed.
    */
   public boolean bufferMove(Move move, String message)
   {
      // Check if client is still connected.
      if (!socket.isConnected())
      {
         close();
         return false;
      }
      
      // Write to buffer.
      try
      {
         output.writeObject(move);
         output.writeObject(message);
      }
      catch (IOException ioe)
      {
         System.out.println(clientID + " had an error while attempting to write to the buffer: " + ioe);
      }
      
      // Implied else.
      return true;
   }
   
   /**
    * @return The gameID associated with this client thread.
    */
   public String getGameID()
   {
      return gameID;
   }
   
   /**
    * @return The clientID associated with this client thread (which was passed by the calling GameServer).
    */
   public int getClientID()
   {
      return clientID;
   }
   
   /**
    * @return True if the client is the black player; false otherwise.
    */
   public boolean isBlack()
   {
      return isBlack;
   }
}
