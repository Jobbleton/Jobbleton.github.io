/**
 * @author Anish Kunduru
 * 
 * This program defines the different type of messages that will be exchanged between the clients and the server.
 * We are using a custom object because it helps us easily determine what the client is doing in a safe way (rather than parsing strings).
 */

package server;

import java.io.Serializable;

public class ServerMessage implements Serializable
{
   // Implement serializable.
   private static final long serialVersionUID = -4060984163424431415L;
   
   /**
    * This enum represents the different type of possible messages.
    */
   public enum Type
   {
      LOGOUT, MOVE
   };
   
   // Object vars.
   private Type messageType;
   private Move move;
   
   /**
    * Constructor that sets up the class variables.
    * 
    * @param type The type of message of ServerMessage.type.
    * @param move The piece that you wish to move. If you are logging out, then move should be null.
    */
   public ServerMessage(Type type, Move move)
   {
      messageType = type;
      this.move = move;
   }
   
   /**
    * @return A ServerMessage.Type enum.
    */
   public Type getMessageType()
   {
      return messageType;
   }
   
   /**
    * @return The move that the client wants to undertake.
    */
   public Move getMove()
   {
      return move;
   }
}
